<?php

// Підключення ACF полів
require_once get_template_directory() . '/acfe-fields.php';

// Налаштування теми
function canape_setup() {
    load_theme_textdomain('canape', get_template_directory() . '/languages');
    add_theme_support('automatic-feed-links');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    set_post_thumbnail_size(765, 380, true);
    add_image_size('canape-hero-thumbnail', 1180, 530, true);
    add_image_size('canape-testimonial-thumbnail', 90, 90, true);

    register_nav_menus(array(
        'primary' => esc_html__('Primary Menu', 'canape'),
        'social'  => esc_html__('Social Menu', 'canape'),
    ));

    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));

    add_theme_support('post-formats', array(
        'quote',
        'link',
    ));
}
add_action('after_setup_theme', 'canape_setup');

// Встановлення ширини контенту
function canape_content_width() {
    $GLOBALS['content_width'] = apply_filters('canape_content_width', 620);

    if (is_page_template('page-templates/full-width-page.php') || is_attachment()) {
        $GLOBALS['content_width'] = 765;
    }
}
add_action('after_setup_theme', 'canape_content_width', 0);

// Реєстрація сайдбарів
function canape_widgets_init() {
    $sidebar_args = array(
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    );

    register_sidebar(array_merge($sidebar_args, array(
        'name' => esc_html__('Main Sidebar', 'canape'),
        'id'   => 'sidebar-1',
    )));

    register_sidebar(array_merge($sidebar_args, array(
        'name' => esc_html__('First Footer Widget Area', 'canape'),
        'id'   => 'sidebar-2',
    )));

    register_sidebar(array_merge($sidebar_args, array(
        'name' => esc_html__('Second Footer Widget Area', 'canape'),
        'id'   => 'sidebar-3',
    )));

    register_sidebar(array_merge($sidebar_args, array(
        'name' => esc_html__('First Front Page Widget Area', 'canape'),
        'id'   => 'sidebar-4',
    )));

    register_sidebar(array_merge($sidebar_args, array(
        'name' => esc_html__('Second Front Page Widget Area', 'canape'),
        'id'   => 'sidebar-5',
    )));

    register_sidebar(array_merge($sidebar_args, array(
        'name' => esc_html__('Third Front Page Widget Area', 'canape'),
        'id'   => 'sidebar-6',
    )));
}
add_action('widgets_init', 'canape_widgets_init');

// Підключення шрифтів
function canape_fonts_url() {
    $fonts_url = '';
    $font_families = array();

    if ('off' !== _x('on', 'Playfair Display font: on or off', 'canape')) {
        $font_families[] = 'Playfair Display:400,400italic,700,700italic';
    }
    if ('off' !== _x('on', 'Noticia Text font: on or off', 'canape')) {
        $font_families[] = 'Noticia Text:400,400italic,700,700italic';
    }
    if ('off' !== _x('on', 'Montserrat font: on or off', 'canape')) {
        $font_families[] = 'Montserrat:400,700';
    }

    if (!empty($font_families)) {
        $query_args = array(
            'family' => urlencode(implode('|', $font_families)),
            'subset' => urlencode('latin,latin-ext'),
        );
        $fonts_url = add_query_arg($query_args, "https://fonts.googleapis.com/css");
    }

    return $fonts_url;
}

// Підключення скриптів і стилів
function canape_scripts() {
    wp_enqueue_style('canape-fonts', canape_fonts_url(), array(), null);
    wp_enqueue_style('genericons', get_template_directory_uri() . '/genericons/genericons.css', array(), '3.3.1');
    wp_enqueue_style('canape-style', get_stylesheet_uri());
    wp_enqueue_style('my-inagro-styles', get_template_directory_uri() . '/css/myInagroCss.css', array('canape-style'), '1.1');

    wp_enqueue_script('canape-script', get_template_directory_uri() . '/js/canape.js', array('jquery'), '20150825', true);
    wp_enqueue_script('canape-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20120206', true);
    wp_enqueue_script('canape-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20130115', true);
    wp_enqueue_script('criteria-script', get_template_directory_uri() . '/js/criteria.js', array('jquery'), '1.0', true);
    wp_localize_script('criteria-script', 'my_ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
    wp_enqueue_script('electricity-status', get_template_directory_uri() . '/js/electricity-status.js', array('jquery'), '1.0', true);
    wp_localize_script('electricity-status', 'electricityAjax', array('ajaxurl' => admin_url('admin-ajax.php')));

    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }

    if (is_front_page() && !is_home() && get_theme_mod('canape_front_testimonials', 1) && canape_has_testimonials()) {
        wp_enqueue_script('canape-flexslider', get_template_directory_uri() . '/js/canape-flexslider.js', array('jquery', 'flexslider'), '20170914', true);
        wp_enqueue_script('flexslider', get_template_directory_uri() . '/js/jquery.flexslider.js', array('jquery'), '20170914', true);
        wp_enqueue_style('flexslider-styles', get_template_directory_uri() . '/css/flexslider.css', array(), '20170914');
    }
}
add_action('wp_enqueue_scripts', 'canape_scripts');

// Створення custom post type "Критерії"
function create_criteria_post_type() {
    register_post_type('criteria', array(
        'labels' => array(
            'name' => __('Критерії'),
            'singular_name' => __('Критерій')
        ),
        'public' => true,
        'has_archive' => true,
        'supports' => array('title', 'editor', 'thumbnail', 'page-attributes'),
        'hierarchical' => true,
    ));
}
add_action('init', 'create_criteria_post_type');

// Додавання ACF полів для критеріїв
function add_acf_fields_for_criteria() {
    if (function_exists('acf_add_local_field_group')) {
        acf_add_local_field_group(array(
            'key' => 'group_criteria',
            'title' => 'Деталі критерію',
            'fields' => array(
                array(
                    'key' => 'field_instruction',
                    'label' => 'Інструкція',
                    'name' => 'instruction',
                    'type' => 'textarea',
                    'required' => 0,
                ),
                array(
                    'key' => 'field_description',
                    'label' => 'Опис',
                    'name' => 'description',
                    'type' => 'textarea',
                    'required' => 0,
                ),
                array(
                    'key' => 'field_file',
                    'label' => 'Файл',
                    'name' => 'file',
                    'type' => 'file',
                    'return_format' => 'url',
                    'required' => 0,
                ),
            ),
            'location' => array(
                array(
                    array(
                        'param' => 'post_type',
                        'operator' => '==',
                        'value' => 'criteria',
                    ),
                ),
            ),
        ));
    }
}
add_action('acf/init', 'add_acf_fields_for_criteria');

// Функція для отримання ієрархії критеріїв
function get_criteria_hierarchy() {
    $args = array(
        'post_type' => 'criteria',
        'posts_per_page' => -1,
        'orderby' => 'menu_order',
        'order' => 'ASC',
        'post_parent' => 0
    );
    
    $parent_criteria = get_posts($args);
    $hierarchy = array();

    foreach ($parent_criteria as $parent) {
        $hierarchy[$parent->ID] = array(
            'title' => $parent->post_title,
            'instruction' => get_field('instruction', $parent->ID),
            'description' => get_field('description', $parent->ID),
            'file' => get_field('file', $parent->ID),
            'children' => get_criteria_children($parent->ID)
        );
    }

    return $hierarchy;
}

function get_criteria_children($parent_id) {
    $args = array(
        'post_type' => 'criteria',
        'posts_per_page' => -1,
        'orderby' => 'menu_order',
        'order' => 'ASC',
        'post_parent' => $parent_id
    );
    
    $children = get_posts($args);
    $child_data = array();

    foreach ($children as $child) {
        $child_data[$child->ID] = array(
            'title' => $child->post_title,
            'instruction' => get_field('instruction', $child->ID),
            'description' => get_field('description', $child->ID),
            'file' => get_field('file', $child->ID),
            'children' => get_criteria_children($child->ID)
        );
    }

    return $child_data;
}
// щоб завантажувати лише цього формату файли
function my_custom_mime_types($mimes) {
    $mimes['xlsx'] = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    $mimes['xls'] = 'application/vnd.ms-excel';
    $mimes['doc'] = 'application/msword';
    $mimes['docx'] = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
    return $mimes;
}
add_filter('upload_mimes', 'my_custom_mime_types');

// Функція для отримання статусу електроенергії
function get_electricity_status() {
    $args = array(
        'post_type' => 'electricity_schedule',
        'posts_per_page' => -1,
    );
    $schedules = get_posts($args);

    $current_time = current_time('H:i');

    foreach ($schedules as $schedule) {
        $start_time = get_field('start_time', $schedule->ID);
        $end_time = get_field('end_time', $schedule->ID);

        if ($current_time >= $start_time && $current_time < $end_time) {
            return false; // світла немає
        }
    }

    return true; // є світло
}

// AJAX-обробник для отримання статусу електроенергії
function electricity_status_ajax() {
    $status = get_electricity_status();
    $icon_class = $status ? 'light-on' : 'light-off';
    wp_send_json(array('hasElectricity' => $status, 'iconClass' => $icon_class));
}
add_action('wp_ajax_electricity_status', 'electricity_status_ajax');
add_action('wp_ajax_nopriv_electricity_status', 'electricity_status_ajax');

// Підключення додаткових файлів
require get_template_directory() . '/inc/template-tags.php';
require get_template_directory() . '/inc/extras.php';
require get_template_directory() . '/inc/customizer.php';
require get_template_directory() . '/inc/jetpack.php';

// Підключення оновлювача теми (тільки для адмін панелі)
if (is_admin()) {
    include dirname(__FILE__) . '/inc/updater.php';
}