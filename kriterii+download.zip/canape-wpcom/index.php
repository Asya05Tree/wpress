<?php get_header(); ?>

<div id="primary" class="content-area">
	<main id="main" class="site-main" role="main">
		<div id="criteria-filter" class="filter-container">
			<button class="filter-button show-all active" data-letter="all">Всі</button>
			<?php
			$args = array(
				'post_type' => 'criteria',
				'posts_per_page' => -1,
				'orderby' => 'title',
				'order' => 'ASC',
				'post_parent' => 0 
			);
			$criteria_query = new WP_Query($args);
			$used_letters = array();

			if ($criteria_query->have_posts()):
				while ($criteria_query->have_posts()):
					$criteria_query->the_post();
					$first_letter = mb_strtoupper(mb_substr(get_the_title(), 0, 1, 'UTF-8'), 'UTF-8');
					if (!in_array($first_letter, $used_letters)) {
						$used_letters[] = $first_letter;
					}
				endwhile;
				wp_reset_postdata();
			endif;

			sort($used_letters);

			foreach ($used_letters as $letter) {
				echo '<button class="filter-button" data-letter="' . esc_attr($letter) . '">' . esc_html($letter) . '</button>';
			}
			?>
		</div>

		<div class="criteria-grid">
			<?php
			$parent_criteria = get_posts(
				array(
					'post_type' => 'criteria',
					'posts_per_page' => -1,
					'post_parent' => 0,
					'orderby' => 'title',
					'order' => 'ASC'
				)
			);

			foreach ($parent_criteria as $parent):
				$children = get_posts(
					array(
						'post_type' => 'criteria',
						'posts_per_page' => -1,
						'post_parent' => $parent->ID,
						'orderby' => 'title',
						'order' => 'ASC'
					)
				);
				?>
				<div class="criteria-item parent-criteria" data-title="<?php echo esc_attr($parent->post_title); ?>">
					<h3 class="criteria-title"><?php echo esc_html($parent->post_title); ?><span
							class="toggle-icon">&#9660;</span></h3>
					<div class="criteria-content">
						<div class="parent-content">
							<h4 class="expand-parent">Розгорнути <?php echo esc_html($parent->post_title); ?></h4>
							<div class="parent-details" style="display: none;">
								<div class="criteria-section instruction">
									<h4>Інструкція:</h4>
									<?php echo wp_kses_post(get_field('instruction', $parent->ID)); ?>
								</div>
								<div class="criteria-section description">
									<h4>Опис:</h4>
									<?php echo wp_kses_post(get_field('description', $parent->ID)); ?>
								</div>
								<?php
								$file_url = get_field('file', $parent->ID);
								if ($file_url):
									?>
									<div class="criteria-section file-preview">
										<h4>Файл:</h4>
										<?php echo do_shortcode('[pdf-embedder url="' . esc_url($file_url) . '" width="100%" height="600px"]'); ?>
										<div class="file-options">
											<button class="action-button download-btn"
												data-file="<?php echo esc_url($file_url); ?>">Завантажити PDF</button>
											<button class="action-button share-btn"
												data-title="<?php echo esc_attr($parent->post_title); ?>">Поділитися</button>
										</div>
									</div>
								<?php endif; ?>
							</div>
						</div>
						<?php foreach ($children as $child): ?>
							<div class="child-criteria">
								<h4 class="child-title"><?php echo esc_html($child->post_title); ?></h4>
								<div class="child-content" style="display: none;">
									<div class="criteria-section instruction">
										<h4>Інструкція:</h4>
										<?php echo wp_kses_post(get_field('instruction', $child->ID)); ?>
									</div>
									<div class="criteria-section description">
										<h4>Опис:</h4>
										<?php echo wp_kses_post(get_field('description', $child->ID)); ?>
									</div>
									<?php
									$file_url = get_field('file', $child->ID);
									if ($file_url):
										?>
										<div class="criteria-section file-preview">
											<h4>Файл:</h4>
											<?php echo do_shortcode('[pdf-embedder url="' . esc_url($file_url) . '" width="100%" height="600px"]'); ?>
											<div class="file-options">
												<button class="action-button download-btn"
													data-file="<?php echo esc_url($file_url); ?>">Завантажити PDF</button>
												<button class="action-button share-btn"
													data-title="<?php echo esc_attr($child->post_title); ?>">Поділитися</button>
											</div>
										</div>
									<?php endif; ?>
								</div>
							</div>
						<?php endforeach; ?>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</main>
</div>

<div class="floating-buttons">
	<button title="<?php esc_attr_e('Відображення опису', 'your-theme-textdomain'); ?>"
		class="floating-button toggle-description">Опис</button>
	<button title="<?php esc_attr_e('Відображення файлу', 'your-theme-textdomain'); ?>"
		class="floating-button toggle-pdf">PDF</button>
</div>

<div class="electricity-status">
	<div class="tomato-icon" title="Наявність світла в офісі"></div>
</div>

<?php get_footer(); ?>