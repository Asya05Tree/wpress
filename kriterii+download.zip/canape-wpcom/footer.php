	</div><!-- #content -->

		<?php get_sidebar( 'footer' ); ?>

		<footer id="colophon" class="site-footer" role="contentinfo">
		<!--	<div class="site-info">
				<span class="sep"> | </span>
			</div> .site-info -->
		</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
