<?php
require_once('../../../../wp-load.php');
require_once(ABSPATH . 'wp-admin/includes/image.php');
require_once(ABSPATH . 'wp-admin/includes/file.php');
require_once(ABSPATH . 'wp-admin/includes/media.php');

if (!wp_verify_nonce($_POST['nonce'], 'download_criteria')) {
    die('Доступ заборонено');
}

$post_id = intval($_POST['post_id']);
$post = get_post($post_id);

if (!$post) {
    die('Критерій не знайдено');
}

$title = $post->post_title;
$content = wp_strip_all_tags($post->post_content);
$image_url = get_the_post_thumbnail_url($post_id, 'full');

require_once('path/to/PHPWord.php');

$phpWord = new \PhpOffice\PhpWord\PhpWord();
$section = $phpWord->addSection();

$section->addText($title, array('bold' => true, 'size' => 16));

if ($image_url) {
    $section->addImage($image_url, array('width' => 300, 'height' => 200));
}


$section->addText($content);


$temp_file = tempnam(sys_get_temp_dir(), 'criteria');
$objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'Word2007');
$objWriter->save($temp_file);


header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
header('Content-Disposition: attachment; filename="' . sanitize_file_name($title) . '.docx"');
header('Cache-Control: max-age=0');
readfile($temp_file);
unlink($temp_file); 
exit;